AIX BOT legal pages for GitHub Pages

1. Create a GitHub repository (for example: aix-bot-legal).
2. Upload the three files in this docs folder to the repository's root.
3. On GitHub, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish the site.

Your URLs will be:
https://YOUR-GITHUB-USERNAME.github.io/aix-bot-legal/privacy.html
https://YOUR-GITHUB-USERNAME.github.io/aix-bot-legal/terms.html

Replace YOUR-GITHUB-USERNAME and aix-bot-legal with your actual GitHub username and repository name.
Review the policy and terms before publishing, especially the contact method and data-retention details.
